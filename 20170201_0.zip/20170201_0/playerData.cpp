#include "stdafx.h"
#include "playerData.h"

HRESULT playerData::init(void)
{
	return S_OK;
}

void playerData::release(void)
{
}
