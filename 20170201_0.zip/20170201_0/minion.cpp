#include "stdafx.h"
#include "minion.h"


minion::minion()
{
}


minion::~minion()
{
}
